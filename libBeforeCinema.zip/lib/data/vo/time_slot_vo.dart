import 'package:json_annotation/json_annotation.dart';

part 'time_slot_vo.g.dart';

@JsonSerializable()
class TimeSlotVO {

  @JsonKey(name: "cinema_day_timeslot_id")
  int id;

  @JsonKey(name: "start_time")
  String startTime;

  bool isSelected ;


  TimeSlotVO(this.id, this.startTime,this.isSelected);

  factory TimeSlotVO.fromJson(Map<String, dynamic> json) =>
      _$TimeSlotVOFromJson(json); // Json to Object #return type is factory object
  Map<String, dynamic> toJson() =>
      _$TimeSlotVOToJson(this); // Object to Json  #return type is Json Map
}
