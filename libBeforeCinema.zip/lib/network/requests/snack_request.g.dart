// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'snack_request.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

SnackRequest _$SnackRequestFromJson(Map<String, dynamic> json) {
  return SnackRequest(
    json['id'] as int,
    json['quantity'] as int,
  );
}

Map<String, dynamic> _$SnackRequestToJson(SnackRequest instance) =>
    <String, dynamic>{
      'id': instance.id,
      'quantity': instance.quantity,
    };
