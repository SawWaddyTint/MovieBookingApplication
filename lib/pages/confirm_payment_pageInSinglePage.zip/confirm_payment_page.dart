import 'dart:io';

import 'package:MovieBookingApplication/data/models/movie_model.dart';
import 'package:MovieBookingApplication/data/models/movie_model_impl.dart';
import 'package:MovieBookingApplication/data/vo/card_vo.dart';
import 'package:MovieBookingApplication/data/vo/seat_plan_vo.dart';
import 'package:MovieBookingApplication/data/vo/user_data_vo.dart';
import 'package:MovieBookingApplication/network/responses/login_data_response.dart';
import 'package:MovieBookingApplication/widgets/form_field_name.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_swiper/flutter_swiper.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:MovieBookingApplication/pages/add_new_card_page.dart';
import 'package:MovieBookingApplication/pages/payslip_page.dart';
import 'package:MovieBookingApplication/resources/colors.dart';
import 'package:MovieBookingApplication/resources/dimens.dart';
import 'package:MovieBookingApplication/resources/strings.dart';
import 'package:MovieBookingApplication/widgets/app_action_btn.dart';

List<CardVO> cardLists;
int focusIndex;
LoginDataResponse loginData;
bool showForm = false;

class ConfirmPaymentPage extends StatefulWidget {
  // final List<CardVO> newCardLists;
  // BuildContext context;
  // ConfirmPaymentPage({this.context, this.newCardLists});
  @override
  _ConfirmPaymentPageState createState() => _ConfirmPaymentPageState();
}

class _ConfirmPaymentPageState extends State<ConfirmPaymentPage> {
  String token;
  UserDataVO userData;
  MovieModel mMovieModel = MovieModelImpl();

  @override
  void initState() {
    super.initState();

    mMovieModel.emailLogin("sawwaddytint@gmail.com", "123").then((value) {
      loginData = value;
      cardLists = loginData.data.cards;
    });
  }

  void _showAddNewCard() async {
    // final newCardLists = await Navigator.push(
    //   context,
    //   MaterialPageRoute(
    //     builder: (context) => AddNewCardPage(cardLists),
    //   ),
    // );
    // setState(() {
    //   cardLists = newCardLists as List<CardVO>;
    //   // focusIndex = cardLists.length - 1;
    // });
    setState(() {
      showForm = true;
    });
  }

  checkField(String cardNumber, String cardHolder, String expDate, String cvc) {
    setState(() {
      if (cardNumber == "") {
        setState(() {
          isCardNumNull = true;
        });
      } else
        isCardNumNull = false;

      if (cardHolder == "") {
        setState(() {
          isCardHolderNull = true;
        });
      } else
        isCardHolderNull = false;

      if (expDate == "") {
        setState(() {
          isExpDateNull = true;
        });
      } else
        isExpDateNull = false;

      if (cvc == "") {
        setState(() {
          isCvcNull = true;
        });
      } else
        isCvcNull = false;

      if (!isCardNumNull && !isCardHolderNull && !isExpDateNull && !isCvcNull) {
        this.addNewCard(cardNumber, cardHolder, expDate, cvc);
      }
    });
  }

  addNewCard(String cardNumber, String cardHolder, String expDate, String cvc) {
    mMovieModel
        .addNewCard('Bearer $token', cardNumber, cardHolder, expDate, cvc)
        .then((value) {
      setState(() {
        cardLists = value;
        // if (newCardLists.length > 0) {
        //   flag = 1;
        //   this._popToPreviousPage(newCardLists);
        // }
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: Icon(
          Icons.chevron_left,
          color: Colors.black,
          size: Medium_sizebox_height,
        ),
      ),
      body: Container(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            PaymentAmountView(),
            SizedBox(
              height: Regular_margin_size,
            ),
            CardSwipeView(),
            Spacer(),
            SizedBox(height: Title_text_size),
            CardHolderInfoView(),
            AddNewCardView(
              (flag) {
                if (flag == 1) {
                  this._showAddNewCard();
                }
              },
            ),
            SizedBox(
              height: Medium_margin_size,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(
                  horizontal: Regular_margin_size_2X),
              child: AppActionBtn(Confirm_txt, () {
                this.checkField(
                    cardNumber.text, cardHolder.text, expDate.text, cvc.text);
              }),
            ),
            SizedBox(
              height: Regular_margin_size_2X,
            ),
          ],
        ),
      ),
    );
  }
}

void _navigateToPayslipPage(BuildContext context) {
  Navigator.push(
    context,
    MaterialPageRoute(
      builder: (context) => PayslipPage(),
    ),
  );
}

class CardHolderInfoView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return (showForm)
        ? Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: Regular_margin_size_2X),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                FormFieldName(Card_num_txt),
                TextField(
                  controller: cardNumber,
                  style: TextStyle(
                    color: Colors.black,
                  ),
                ),
                SizedBox(
                  height: Medium_margin_size,
                ),
                FormFieldName(Card_holder_txt),
                TextField(
                  controller: cardHolder,
                  style: TextStyle(
                    color: Colors.black,
                  ),
                ),
                SizedBox(
                  height: Medium_margin_size,
                ),
                Row(
                  children: [
                    Flexible(child: FormFieldName(Expiration_txt)),
                    SizedBox(
                      width: 75.0,
                    ),
                    Flexible(child: FormFieldName(Cvc_txt)),
                  ],
                ),
                Row(
                  children: [
                    Flexible(
                      child: TextField(
                        controller: expDate,
                        style: TextStyle(
                          color: Colors.black,
                        ),
                      ),
                    ),
                    SizedBox(
                      width: Medium_title_text_size,
                    ),
                    Flexible(
                      child: TextField(
                        controller: cvc,
                        style: TextStyle(
                          color: Colors.black,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          )
        : Center(
            child: CircularProgressIndicator(),
          );
  }
}

class AddNewCardView extends StatelessWidget {
  final Function onTapAdd;
  AddNewCardView(this.onTapAdd);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: Regular_margin_size_2X),
      child: GestureDetector(
        onTap: () {
          this.onTapAdd(1);
        },
        child: Row(
          children: [
            Icon(
              Icons.add_circle,
              color: Subtotal_text_color,
              size: Medium_margin_size,
            ),
            SizedBox(
              width: Xs_margin_size,
            ),
            Text(
              Add_new_card_txt,
              style: TextStyle(
                fontSize: Regular_title_text_size,
                color: Subtotal_text_color,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class CardSwipeView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
        height: 180.0,
        child: CarouselSlider(
          options: CarouselOptions(
              height: 400.0,
              enlargeCenterPage: true,
              // enableInfiniteScroll: false,
              initialPage: focusIndex),
          items: cardLists.map((card) {
            return Builder(
              builder: (BuildContext context) {
                return Container(
                    width: MediaQuery.of(context).size.width,
                    // height: 180.0,
                    margin: EdgeInsets.symmetric(horizontal: 5.0),
                    decoration: BoxDecoration(color: Colors.transparent),
                    child: Card(
                      child: Stack(children: [
                        Positioned.fill(
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(6.0),
                              gradient: LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [
                                  Color.fromRGBO(141, 119, 253, 1.0),
                                  Color.fromRGBO(168, 122, 255, 1.0)
                                ],
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(18.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Text(
                                    "VISA",
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontSize: Regular_title_text_size,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  Spacer(),
                                  Icon(
                                    Icons.more_horiz,
                                    color: Colors.white,
                                  )
                                ],
                              ),
                              SizedBox(
                                height: 26,
                              ),
                              Row(
                                children: [
                                  Text(
                                    "* * * *  * * * *  * * * *",
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontSize: Small_text_size,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  Spacer(),
                                  Text(
                                    card.cardNumber,
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontSize: Regular_margin_size_2X,
                                        fontWeight: FontWeight.w500),
                                  )
                                ],
                              ),
                              SizedBox(
                                height: Regular_margin_size_2X,
                              ),
                              Row(
                                children: [
                                  Text(
                                    "Card Holder",
                                    style: TextStyle(
                                      color: Card_holder_text_color,
                                      fontWeight: FontWeight.w400,
                                      fontSize: Subtitle_text_size,
                                    ),
                                  ),
                                  Spacer(),
                                  Text(
                                    "Expires",
                                    style: TextStyle(
                                      color: Card_holder_text_color,
                                      fontWeight: FontWeight.w400,
                                      fontSize: Subtitle_text_size,
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 4.0,
                              ),
                              Row(
                                children: [
                                  Text(
                                    card.cardHolder,
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w600,
                                      fontSize: Subtitle_text_size,
                                    ),
                                  ),
                                  Spacer(),
                                  Text(
                                    card.expirationDate,
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w600,
                                      fontSize: Subtitle_text_size,
                                    ),
                                  ),
                                ],
                              )
                            ],
                          ),
                        ),
                      ]),
                    ));
              },
            );
          }).toList(),
        ));
  }
}

// class CardSwipeView extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//         height: 180.0,
//         child: Swiper(
//           fade: 0.3,
//           itemBuilder: (BuildContext context, int index) {
//             // );
//             return Card(
//               child: Stack(children: [
//                 Positioned.fill(
//                   child: Container(
//                     decoration: BoxDecoration(
//                       borderRadius: BorderRadius.circular(6.0),
//                       gradient: LinearGradient(
//                         begin: Alignment.topCenter,
//                         end: Alignment.bottomCenter,
//                         colors: [
//                           Color.fromRGBO(141, 119, 253, 1.0),
//                           Color.fromRGBO(168, 122, 255, 1.0)
//                         ],
//                       ),
//                     ),
//                   ),
//                 ),
//                 Padding(
//                   padding: const EdgeInsets.all(18.0),
//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Row(
//                         crossAxisAlignment: CrossAxisAlignment.center,
//                         children: [
//                           Text(
//                             "VISA",
//                             style: TextStyle(
//                                 color: Colors.white,
//                                 fontSize: Regular_title_text_size,
//                                 fontWeight: FontWeight.bold),
//                           ),
//                           Spacer(),
//                           Icon(
//                             Icons.more_horiz,
//                             color: Colors.white,
//                           )
//                         ],
//                       ),
//                       SizedBox(
//                         height: 26,
//                       ),
//                       Row(
//                         children: [
//                           Text(
//                             "* * * *  * * * *  * * * *",
//                             style: TextStyle(
//                                 color: Colors.white,
//                                 fontSize: Regular_title_text_size,
//                                 fontWeight: FontWeight.bold),
//                           ),
//                           Spacer(),
//                           Text(
//                             "8014",
//                             style: TextStyle(
//                                 color: Colors.white,
//                                 fontSize: Regular_margin_size_3X,
//                                 fontWeight: FontWeight.w500),
//                           )
//                         ],
//                       ),
//                       SizedBox(
//                         height: Regular_margin_size_2X,
//                       ),
//                       Row(
//                         children: [
//                           Text(
//                             "Card Holder",
//                             style: TextStyle(
//                               color: Card_holder_text_color,
//                               fontWeight: FontWeight.w400,
//                               fontSize: Subtitle_text_size,
//                             ),
//                           ),
//                           Spacer(),
//                           Text(
//                             "Expires",
//                             style: TextStyle(
//                               color: Card_holder_text_color,
//                               fontWeight: FontWeight.w400,
//                               fontSize: Subtitle_text_size,
//                             ),
//                           ),
//                         ],
//                       ),
//                       SizedBox(
//                         height: 4.0,
//                       ),
//                       Row(
//                         children: [
//                           Text(
//                             "Lily Johnson",
//                             style: TextStyle(
//                               color: Colors.white,
//                               fontWeight: FontWeight.w600,
//                               fontSize: Subtitle_text_size,
//                             ),
//                           ),
//                           Spacer(),
//                           Text(
//                             "08/21",
//                             style: TextStyle(
//                               color: Colors.white,
//                               fontWeight: FontWeight.w600,
//                               fontSize: Subtitle_text_size,
//                             ),
//                           ),
//                         ],
//                       )
//                     ],
//                   ),
//                 ),
//               ]),
//             );
//           },
//           // itemHeight: 100,
//           // itemWidth: 200,
//           itemCount: 10,
//           viewportFraction: 0.8,
//           scale: 0.9,
//         ));
//   }
// }

class PaymentAmountView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: Regular_margin_size_2X),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Payment amount",
            style: TextStyle(
              color: ComboSet_details_color,
              fontWeight: FontWeight.w400,
              fontSize: Subtitle_text_size,
            ),
          ),
          SizedBox(
            height: XXS_margin_size,
          ),
          Text(
            "\$ 926.21",
            style: TextStyle(
                color: Colors.black,
                fontSize: Regular_sizebox_height,
                fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }
}
