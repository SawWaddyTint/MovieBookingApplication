import 'package:MovieBookingApplication/data/vo/time_slot_vo.dart';
import 'package:json_annotation/json_annotation.dart';

part 'cinema_vo.g.dart';

@JsonSerializable()

class CinemaVO{
  @JsonKey(name: "cinema_id")
  int cinemaId;

  @JsonKey(name: "cinema")
  String name;

  @JsonKey(name: "timeslots")
  List<TimeSlotVO> timeSlots;


  CinemaVO(this.cinemaId, this.name, this.timeSlots);

  factory CinemaVO.fromJson(Map<String, dynamic> json) =>
      _$CinemaVOFromJson(json); // Json to Object #return type is factory object
  Map<String, dynamic> toJson() =>
      _$CinemaVOToJson(this); // Object to Json  #return type is Json Map
}