// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cinema_vo.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

CinemaVO _$CinemaVOFromJson(Map<String, dynamic> json) {
  return CinemaVO(
    json['cinema_id'] as int,
    json['cinema'] as String,
    (json['timeslots'] as List)
        ?.map((e) =>
            e == null ? null : TimeSlotVO.fromJson(e as Map<String, dynamic>))
        ?.toList(),
  );
}

Map<String, dynamic> _$CinemaVOToJson(CinemaVO instance) => <String, dynamic>{
      'cinema_id': instance.cinemaId,
      'cinema': instance.name,
      'timeslots': instance.timeSlots,
    };
