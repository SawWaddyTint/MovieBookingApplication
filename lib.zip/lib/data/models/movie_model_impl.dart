import 'package:MovieBookingApplication/data/models/movie_model.dart';
import 'package:MovieBookingApplication/data/vo/card_vo.dart';
import 'package:MovieBookingApplication/data/vo/cinema_vo.dart';
import 'package:MovieBookingApplication/data/vo/facebook_data_vo.dart';
import 'package:MovieBookingApplication/data/vo/movie_detail_vo.dart';
import 'package:MovieBookingApplication/data/vo/movie_vo.dart';
import 'package:MovieBookingApplication/data/vo/seat_plan_vo.dart';
import 'package:MovieBookingApplication/data/vo/snack_vo.dart';
import 'package:MovieBookingApplication/network/movie_data_agent.dart';
import 'package:MovieBookingApplication/network/responses/checkout_response.dart';
import 'package:MovieBookingApplication/network/requests/check_out_request.dart';
import 'package:MovieBookingApplication/network/responses/log_out_response.dart';
import 'package:MovieBookingApplication/network/responses/login_data_response.dart';
import 'package:MovieBookingApplication/network/retrofit_data_agent_impl.dart';
import 'package:MovieBookingApplication/persistance/dao/login_data_response_dao.dart';
import 'package:MovieBookingApplication/persistance/dao/movie_dao.dart';

class MovieModelImpl extends MovieModel {
  MovieDataAgent mDataAgent = RetrofitDataAgentImpl();
  static final MovieModelImpl _singleton = MovieModelImpl._internal();

  factory MovieModelImpl() {
    return _singleton;
  }

  MovieModelImpl._internal();

  // Daos

  LoginDataResponseDao loginDao = LoginDataResponseDao();
  MovieDao mMovieDao = MovieDao();
  // GenreDao mGenreDao = GenreDao();
  // ActorDao mActorDao = ActorDao();

  @override
  Future<FacebookDataVO> getFacebookProfileData(String token) {
    return mDataAgent.getFacebookProfileData(token);
  }

  @override
  Future<List<MovieVO>> getMovieList(String status) {
    return mDataAgent.getMovieList(status).then((movies) async {
      List<MovieVO> movieLists = movies.map((movie) {
        return movie;
      }).toList();
      mMovieDao.saveMovies(movieLists);
      return Future.value(movies);
    });
  }

  @override
  Future<MovieDetailVO> getMovieDetails(int id) {
    // TODO: implement getMovieDetails
    return mDataAgent.getMovieDetails(id).then((movie) async {
      mMovieDao.saveSingleMovie(movie);
      return Future.value(movie);
    });
  }

  @override
  Future<List<CinemaVO>> getCinemaTimeSlotList(String token, String date) {
    return mDataAgent.getCinemaTimeSlotList(token, date);
  }

  @override
  Future<LoginDataResponse> emailLogin(String email, String password) {
    return mDataAgent.emailLogin(email, password).then((value) async {
      loginDao.saveLoginDataResponse(value);
      return Future.value(value);
    });
  }

  @override
  Future<List<List<SeatPlanVO>>> getSeatPlan(
      String token, int timeSlotId, String bookingDate) {
    return mDataAgent.getSeatPlan(token, timeSlotId, bookingDate);
  }

  @override
  Future<LoginDataResponse> register(
      String name, String email, String phone, String password,
      {String facebookAccessToken, String googleAccessToken}) {
    return mDataAgent
        .register(name, email, phone, password,
            facebookAccessToken: facebookAccessToken,
            googleAccessToken: googleAccessToken)
        .then((value) async {
      loginDao.saveLoginDataResponse(value);
      return Future.value(value);
    });
  }

  @override
  Future<LoginDataResponse> getLoginDataFromDatabase() {
    return Future.value(loginDao.getLoginData(1));
  }

  @override
  Future<LogOutResponse> getLogOut(String token) {
    return mDataAgent.getLogOut(token);
  }

  @override
  Future<List<SnackVO>> getSnacks(String token) {
    return mDataAgent.getSnacks(token);
  }

  @override
  Future<List<CardVO>> addNewCard(String token, String cardNumber,
      String cardHolder, String expDate, String cvc) {
    return mDataAgent.addNewCard(token, cardNumber, cardHolder, expDate, cvc);
  }

  @override
  Future<List<MovieVO>> getAllMoviesFromDatabase() {
    return Future.value(mMovieDao.getAllMovies().toList());
  }

  @override
  Future<MovieDetailVO> getSigleMovieFromDatabase(int movieId) {
    return Future.value(mMovieDao.getSingleMovies(movieId));
  }

  @override
  Future<LoginDataResponse> facebookLogin(String accessToken) {
    return mDataAgent.facebookLogin(accessToken).then((value) async {
      loginDao.saveLoginDataResponse(value);
      return Future.value(value);
    });
  }

  @override
  Future<LoginDataResponse> googleLogin(String accessToken) {
    return mDataAgent.googleLogin(accessToken).then((value) async {
      loginDao.saveLoginDataResponse(value);
      return Future.value(value);
    });
  }

  @override
  Future<CheckoutResponse> checkOut(
      String token, CheckOutRequest checkOutRequest) {
    return mDataAgent.checkOut(token, checkOutRequest);
  }
  // @override
  // Future<MovieVO> getMovieDetailsFromDatabase(int movieId) {
  //   return Future.value(mMovieDao.getMovieById(movieId));
  // }

}
