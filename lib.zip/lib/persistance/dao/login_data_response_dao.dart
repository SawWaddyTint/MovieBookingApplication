import 'package:MovieBookingApplication/network/responses/login_data_response.dart';
import 'package:MovieBookingApplication/persistance/hive_constants.dart';
import 'package:hive/hive.dart';


class LoginDataResponseDao {
  static final LoginDataResponseDao _singleton = LoginDataResponseDao._internal();

  factory LoginDataResponseDao() {
    return _singleton;
  }
  LoginDataResponseDao._internal();



  void saveLoginDataResponse(LoginDataResponse dataResponse) async {
    return getLoginDataResponseBox().put(1, dataResponse);
  }

  LoginDataResponse getLoginData(int loginId) {
    return getLoginDataResponseBox().get(loginId);
  }
  Box<LoginDataResponse> getLoginDataResponseBox() {
    return Hive.box<LoginDataResponse>(BOX_NAME_LOGIN_DATA_RESPONSE_VO);
  }
}
