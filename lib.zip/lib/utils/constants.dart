String SEAT_TYPE_AVAILABLE = "available";
String SEAT_TYPE_TAKEN = "taken";
String SEAT_TYPE_TEXT = "text";
String SEAT_TYPE_EMPTY = "space";
